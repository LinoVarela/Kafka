#!/bin/bash

curl -X GET http://connect:8083/connectors/
